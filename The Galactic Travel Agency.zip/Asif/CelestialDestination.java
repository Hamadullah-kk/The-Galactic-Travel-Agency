class CelestialDestination{
 
String name;   
String type;   
double distanceFromEarth;
boolean hasHabitablePlanets;
double basePackageCost; 

CelestialDestination(String name, String type, double distanceFromEarth, boolean hasHabitablePlanets, double basePackageCost){
	
	this.name = name;
	this.type = type;
	this.distanceFromEarth = distanceFromEarth;
	this.hasHabitablePlanets = hasHabitablePlanets;
	this.basePackageCost = basePackageCost;
}



void displayDestinationInfo(){
	System.out.println("Destination: "+name);
	System.out.println("Type: "+type);
	System.out.println("Distance: "+distanceFromEarth+" light-years");
	System.out.println("Habitable Planets: "+hasHabitablePlanets);
	System.out.println("-------------------------------------------");
	

}

double calculateTotalPackageCost(String packageType){
  double totalcost = 0;
 switch(packageType){
 case "Basic":
 	totalcost = basePackageCost * 1.2;
 	break;

 case "Luxury":
 	totalcost = basePackageCost * 1.5;
 	break;

case "VIP":
    totalcost = basePackageCost * 2.0;
    break;   
default:
	System.out.println("An invalid package type");
 }
 return totalcost;
}

String getTravelRecommendations(){
  
if(hasHabitablePlanets){
    return "Explore potentially habitable worlds!";
}
else if(type == "Star"){
   return "Witness the raw power of a star!";
}else{
	return "A unique and exciting destination!";
} 
	
}

boolean isDestinationReachable(int maxDistance){
	
if(distanceFromEarth <= maxDistance){
       return true;
}else{
	return false;
}
}

String getDestinationSummary(boolean includeDistance){
	if(includeDistance){
		return  name + " (" + distanceFromEarth + " light-years)"; 
}else{
	return name;
}

}


public static void main(String[] args){
  
  int maxTravel = 2000;
 CelestialDestination p1 = new CelestialDestination("Mars", "Planet", 0.0000158, true, 5000);  
 CelestialDestination p2 = new CelestialDestination("Andromeda Galaxy", "Galaxy", 2500000, false, 20000);
 CelestialDestination p3 = new CelestialDestination("Betelgeuse", "Star", 642, false, 15000);	

p1.displayDestinationInfo();
p2.displayDestinationInfo();
p3.displayDestinationInfo();


  System.out.println("Mars VIP Package Cost: $" + p1.calculateTotalPackageCost("VIP"));
System.out.println("Andromeda Luxury Package Cost: $" + p2.calculateTotalPackageCost("Luxury"));
System.out.println("Betelgeuse Basic Package Cost: $" + p3.calculateTotalPackageCost("Basic"));

 System.out.println("---------------------------------------------------");
System.out.println("\nTravel Recommendation for p1: " + p1.getTravelRecommendations());
System.out.println("Travel Recommendation for p2: " + p2.getTravelRecommendations());
System.out.println("Travel Recommendation for p3: " + p3.getTravelRecommendations());

 System.out.println("---------------------------------------------------");
System.out.println("\nCan we reach Mars within " + maxTravel + " light-years? " + p1.isDestinationReachable(maxTravel));
System.out.println("Can we reach Andromeda within " + maxTravel + " light-years? " + p2.isDestinationReachable(maxTravel));
System.out.println("Can we reach Betelgeuse within " + maxTravel + " light-years? " + p3.isDestinationReachable(maxTravel));

 System.out.println(p1.calculateTotalPackageCost("---------------------------------------------------"));
 System.out.println("\nDestination Summary"+p1.getDestinationSummary(true));
 System.out.println("\nDestination Summary"+p2.getDestinationSummary(false)); 
 System.out.println("\nDestination Summary"+p3.getDestinationSummary(false));

}
}